package com.yourapp;

import android.app.admin.DeviceAdminReceiver;

public class DeviceAdminReceiver extends DeviceAdminReceiver {}