# Family Tracker App

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your-repo/family-tracker.git
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file and configure it:
   ```env
   API_URL=https://api.familytracker.com
   MAPBOX_TOKEN=your_mapbox_token
   ```

4. Start the app:
   ```bash
   npm start
   ```

## Features
- Login and Registration
- Family Dashboard
- Location Tracking
- Emergency Notifications