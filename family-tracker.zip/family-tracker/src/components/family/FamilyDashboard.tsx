import React from 'react';
import { View, Text, Button } from 'react-native';

const FamilyDashboard = ({ navigation }: any) => {
  return (
    <View>
      <Text>Family Dashboard</Text>
      <Button title="View Map" onPress={() => navigation.navigate('FamilyMap')} />
      <Button title="View Profile" onPress={() => navigation.navigate('UserProfile')} />
    </View>
  );
};

export default FamilyDashboard;