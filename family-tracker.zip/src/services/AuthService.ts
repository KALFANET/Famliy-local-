export const AuthService = {
    login: async (email: string, password: string) => {
        if (email === "admin@family.com" && password === "1234") {
            return { token: "fake-token" };
        }
        throw new Error("Invalid credentials");
    },
    register: async (email: string, password: string) => {
        console.log("Registering user:", email);
        return { message: "User registered successfully" };
    },
};