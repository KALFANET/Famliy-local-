import React, { useEffect } from 'react';
import * as Notifications from 'expo-notifications';

const NotificationSystem = () => {
    useEffect(() => {
        const subscription = Notifications.addNotificationReceivedListener((notification) => {
            console.log('Notification Received:', notification);
        });

        return () => subscription.remove();
    }, []);

    return null;
};

export default NotificationSystem;