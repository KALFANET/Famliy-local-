import React from 'react';
import { View, Text } from 'react-native';

const FamilyMap = () => {
    return (
        <View>
            <Text>Family Map</Text>
        </View>
    );
};

export default FamilyMap;