import React from 'react';
import { View, Text } from 'react-native';

const UserProfile = () => {
    return (
        <View>
            <Text>User Profile</Text>
        </View>
    );
};

export default UserProfile;