import React from 'react';
import { View, Button, StyleSheet } from 'react-native';

const EmergencyButton = () => {
    const handleEmergencyPress = () => {
        alert('Emergency Alert Sent!');
    };

    return (
        <View style={styles.container}>
            <Button title="SOS" color="red" onPress={handleEmergencyPress} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
});

export default EmergencyButton;