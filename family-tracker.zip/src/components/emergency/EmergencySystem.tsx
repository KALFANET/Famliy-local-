import React from 'react';
import { View, Text } from 'react-native';

const EmergencySystem = () => {
    return (
        <View>
            <Text>Emergency System</Text>
        </View>
    );
};

export default EmergencySystem;