import React, { createContext, useState } from 'react';

export const AuthContext = createContext({
    login: async (email: string, password: string) => {},
    logout: async () => {},
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    const login = async (email: string, password: string) => {
        // Placeholder for actual auth logic
        console.log('Logging in:', email);
        setIsAuthenticated(true);
    };

    const logout = async () => {
        console.log('Logging out');
        setIsAuthenticated(false);
    };

    return (
        <AuthContext.Provider value={{ login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};