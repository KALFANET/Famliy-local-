import React, { createContext, useState } from 'react';

export const FamilyContext = createContext({
    familyMembers: [],
    addFamilyMember: (member: any) => {},
});

export const FamilyProvider = ({ children }: { children: React.ReactNode }) => {
    const [familyMembers, setFamilyMembers] = useState<any[]>([]);

    const addFamilyMember = (member: any) => {
        setFamilyMembers([...familyMembers, member]);
    };

    return (
        <FamilyContext.Provider value={{ familyMembers, addFamilyMember }}>
            {children}
        </FamilyContext.Provider>
    );
};